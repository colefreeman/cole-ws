if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
from datetime import datetime

@transformer
def normalize_contacts(df, *args, **kwargs):
    """
    Normalize contact data formatting
    """
    print(f"🧹 Normalizing {len(df)} contacts...")
    
    # Make a copy to avoid modifications to the original
    df_normalized = df.copy()
    
    # Normalize email addresses
    if 'email' in df_normalized.columns:
        # Convert to lowercase and strip whitespace
        df_normalized['email'] = df_normalized['email'].astype(str).str.lower().str.strip()
    
    # Normalize names
    for name_col in ['first_name', 'last_name']:
        if name_col in df_normalized.columns:
            # Convert to title case and strip whitespace
            df_normalized[name_col] = df_normalized[name_col].astype(str).str.title().str.strip()
    
    # Normalize company name
    if 'company_name' in df_normalized.columns:
        # Strip whitespace
        df_normalized['company_name'] = df_normalized['company_name'].astype(str).str.strip()
    
    # Normalize phone numbers to (XXX) XXX-XXXX format
    if 'phone' in df_normalized.columns:
        # Extract digits only
        df_normalized['phone'] = df_normalized['phone'].astype(str).apply(
            lambda x: ''.join([c for c in x if c.isdigit()])
        )
        # Format as (XXX) XXX-XXXX if we have 10 digits
        df_normalized['phone'] = df_normalized['phone'].apply(
            lambda x: f"({x[0:3]}) {x[3:6]}-{x[6:10]}" if len(x) >= 10 else x
        )
    
    # Add a timestamp to track when normalization occurred
    df_normalized['normalized_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    print("✅ Normalization complete")
    return df_normalized