if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def clean_dataframe(df, *args, **kwargs):
    """
    Clean the loaded dataframe by removing redundant columns and fixing any issues
    """
    print(f"Cleaning dataframe with {len(df)} rows...")
    
    # Remove the redundant "Unnamed: 0" column
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])
    
    # Reset index if needed
    df = df.reset_index(drop=True)
    
    print("✅ DataFrame cleaned")
    return df