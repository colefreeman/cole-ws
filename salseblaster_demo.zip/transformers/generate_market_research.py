if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
import random
import time
from datetime import datetime
from typing import Dict, Any
import requests
from bs4 import BeautifulSoup
import json
from urllib.parse import urljoin

@transformer
def scrape_company_website(df, *args, **kwargs):
    """
    Enrich contact data by scraping the company's about page.
    Specifically designed to scrape Mage.ai's about page for this example.
    
    Args:
        df (DataFrame): Normalized contact data
    
    Returns:
        DataFrame: Enriched contact data with scraped website information
    """
    
    # Make a copy of the input dataframe
    enriched_df = df.copy()
    
    # Add columns for scraped data - removed the three specified columns
    enriched_df['company_description'] = None
    enriched_df['scrape_status'] = None
    enriched_df['last_scraped'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # Define headers for requests to avoid being blocked
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0'
    }
    
    # Function to extract company domain from email
    def extract_domain_from_email(email):
        if pd.isna(email):
            return None
        try:
            return email.split('@')[1]
        except IndexError:
            return None
    
    # Function to get the main website domain based on company name
    def get_website_domain(company_name, email_domain=None):
        if 'mage' in company_name.lower() or (email_domain and 'mage.ai' in email_domain.lower()):
            return 'mage.ai'  # Direct match for our example
        
        # For other companies, you could implement a more generic approach
        # such as "{company_name}.com" or use a domain lookup service
        return None
    
    # Function to scrape the about page
    def scrape_about_page(domain):
        try:
            base_url = f"https://{domain}"
            about_url = f"{base_url}/about"
            
            print(f"Scraping about page: {about_url}")
            
            # Get the about page
            response = requests.get(about_url, headers=headers, timeout=15)
            
            # Check if we got a valid response
            if response.status_code != 200:
                print(f"Failed to access {about_url}, status code: {response.status_code}")
                
                # Try alternative URL patterns
                alternative_urls = [
                    f"{base_url}/about-us",
                    f"{base_url}/company",
                    f"{base_url}/team",
                    f"{base_url}/our-story"
                ]
                
                for alt_url in alternative_urls:
                    print(f"Trying alternative URL: {alt_url}")
                    alt_response = requests.get(alt_url, headers=headers, timeout=15)
                    if alt_response.status_code == 200:
                        response = alt_response
                        about_url = alt_url
                        print(f"Successfully accessed alternative URL: {alt_url}")
                        break
                
                if response.status_code != 200:
                    # If we still don't have a valid page, try the main website
                    print(f"Trying main website: {base_url}")
                    response = requests.get(base_url, headers=headers, timeout=15)
                    about_url = base_url
            
            # If we still don't have a valid page, return error
            if response.status_code != 200:
                return {
                    'status': 'error',
                    'message': f"Failed to access website. Status code: {response.status_code}"
                }
            
            # Parse the HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract company description
            company_description = ""
            
            # Look for common about page elements
            about_sections = soup.find_all(['section', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['about', 'company', 'mission', 'story', 'who-we-are']))
            
            for section in about_sections:
                paragraphs = section.find_all('p')
                for p in paragraphs:
                    if len(p.text.strip()) > 50:  # Only consider substantial paragraphs
                        company_description += p.text.strip() + " "
            
            # If no description found in about sections, look more broadly
            if not company_description:
                # Find substantial paragraphs elsewhere on the page
                for p in soup.find_all('p'):
                    if len(p.text.strip()) > 100:  # Only consider substantial paragraphs
                        company_description += p.text.strip() + " "
                        if len(company_description) > 1000:
                            break
            
            # Extract company values if available
            company_values = []
            values_sections = soup.find_all(['section', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['values', 'principles', 'culture']))
            
            for section in values_sections:
                value_items = section.find_all(['h3', 'h4', 'strong'])
                for item in value_items:
                    value_text = item.text.strip()
                    if 10 < len(value_text) < 100:  # Likely a value heading
                        company_values.append(value_text)
            
            # Get team information if available
            team_info = []
            team_sections = soup.find_all(['section', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['team', 'people', 'leadership', 'founders']))
            
            for section in team_sections:
                # Look for team member cards or listings
                team_members = section.find_all(['div', 'article'], class_=lambda c: c and any(x in str(c).lower() for x in ['member', 'person', 'profile', 'card']))
                
                for member in team_members:
                    name = ""
                    title = ""
                    
                    name_elem = member.find(['h3', 'h4', 'h5', 'strong'])
                    if name_elem:
                        name = name_elem.text.strip()
                    
                    title_elem = member.find(['p', 'span', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['title', 'role', 'position']))
                    if title_elem:
                        title = title_elem.text.strip()
                    
                    if name and title:
                        team_info.append({"name": name, "title": title})
            
            # Get product information from the main page
            product_info = ""
            
            # Try to find the product page
            product_link = soup.find('a', text=lambda t: t and 'product' in t.lower())
            if product_link and 'href' in product_link.attrs:
                product_url = urljoin(base_url, product_link['href'])
                try:
                    product_response = requests.get(product_url, headers=headers, timeout=15)
                    if product_response.status_code == 200:
                        product_soup = BeautifulSoup(product_response.text, 'html.parser')
                        product_sections = product_soup.find_all(['section', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['product', 'features', 'solution']))
                        
                        for section in product_sections:
                            for p in section.find_all('p'):
                                if len(p.text.strip()) > 50:  # Only consider substantial paragraphs
                                    product_info += p.text.strip() + " "
                                    if len(product_info) > 1000:
                                        break
                except Exception as e:
                    print(f"Error scraping product page: {str(e)}")
            
            # If we couldn't find product info from a dedicated page, look on the main page
            if not product_info:
                product_sections = soup.find_all(['section', 'div'], class_=lambda c: c and any(x in str(c).lower() for x in ['product', 'features', 'solution']))
                
                for section in product_sections:
                    for p in section.find_all('p'):
                        if len(p.text.strip()) > 50:  # Only consider substantial paragraphs
                            product_info += p.text.strip() + " "
                            if len(product_info) > 1000:
                                break
            
            # Compile all scraped information - removed the three fields
            return {
                'status': 'success',
                'company_description': company_description[:2000],  # Limit length
                'url_scraped': about_url
            }
            
        except Exception as e:
            print(f"Error scraping about page for {domain}: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    # Process each row in the dataframe
    for idx, row in enriched_df.iterrows():
        if pd.isna(row['company_name']):
            continue
            
        print(f"\nProcessing: {row['first_name']} {row['last_name']} at {row['company_name']}")
        
        # For Mage.ai specifically
        if 'mage' in row['company_name'].lower():
            domain = 'mage.ai'
        else:
            # For other companies, extract domain from email or use other methods
            email_domain = extract_domain_from_email(row['email'])
            domain = get_website_domain(row['company_name'], email_domain)
        
        if domain:
            print(f"Scraping data for domain: {domain}")
            
            # Scrape the about page
            scraped_data = scrape_about_page(domain)
            
            # Update the dataframe with scraped information
            if scraped_data['status'] == 'success':
                enriched_df.at[idx, 'company_description'] = scraped_data['company_description']
                enriched_df.at[idx, 'scrape_status'] = 'success'
                print(f"✓ Successfully scraped data for {domain}")
                print(f"  - Description length: {len(scraped_data['company_description'])} chars")
            else:
                enriched_df.at[idx, 'scrape_status'] = f"error: {scraped_data['message']}"
                print(f"✗ Failed to scrape data for {domain}: {scraped_data['message']}")
        else:
            enriched_df.at[idx, 'scrape_status'] = 'error: could not determine website domain'
            print(f"✗ Could not determine website domain for {row['company_name']}")
        
        # Add a small delay between requests to avoid overloading servers
        time.sleep(2)
    
    print(f"\nEnriched {len(enriched_df)} contacts with website data")
    return enriched_df