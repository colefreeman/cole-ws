if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
import os
import time
import json
import anthropic  # Need to import the Anthropic library
import requests

@transformer
def generate_market_research(df, *args, **kwargs):
    """
    Generate AI market research reports for each company using Anthropic Claude.
    
    Args:
        df (DataFrame): Contact data with scraped company description
    
    Returns:
        DataFrame: Contact data with added market research report
    """
    # Make a copy of the input dataframe
    research_df = df.copy()
    
    # Add column for market research
    research_df['market_research'] = None
    
    # Get Anthropic API key from environment or Mage secrets
    api_key = "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"
    if not api_key:
        try:
            from mage_ai.data_preparation.shared.secrets import get_secret_value
            api_key = get_secret_value('anthropic_api_key')
        except:
            print("Warning: Anthropic API key not found. Using mock data for demonstration.")
            # For demonstration, we'll add mock data if API key isn't available
            for idx, row in research_df.iterrows():
                research_df.at[idx, 'market_research'] = f"Mock market research for {row['company_name']}. This is placeholder text."
            return research_df
    
    # Initialize Anthropic client if API key is available
    client = anthropic.Anthropic(api_key=api_key)
    
    # Get company info from pipeline configuration or set defaults
    company_name = kwargs.get('company_name', 'Our Company')
    hero_offer = kwargs.get('hero_offer', 'Our Data Pipeline Solution')
    hero_offer_details = kwargs.get('hero_offer_details', 'A comprehensive data orchestration platform')
    
    # Process each row
    for idx, row in research_df.iterrows():
        # Skip if missing company description
        if pd.isna(row['company_description']) or row['scrape_status'] != 'success':
            research_df.at[idx, 'market_research'] = "Could not generate market research due to missing company description."
            continue
            
        print(f"\nGenerating market research for: {row['company_name']}")
        
        # Extract context data
        company_name_from_row = row['company_name'] if not pd.isna(row['company_name']) else "the company"
        company_description = row['company_description']
        
        # Prepare prompt for Claude
        system_prompt = """You are an expert market research analyst specializing in B2B SaaS companies. 
        Your task is to create a detailed market research report based on the provided company description.
        Use the company description to extract insights about the company's business model, target market, 
        and potential challenges. Where information is missing, make reasonable inferences based on the industry context.
        Format your report in clear, concise markdown."""
        
        user_prompt = f"""
        Write a detailed market research report for {company_name_from_row}.
        
        Available information:
        - Company Description: {company_description}
        
        The report should include:
        1. Company Overview: What does the company do? What are their main products/services?
        2. Industry Analysis: What industry are they in? What are the key trends and competitors in this industry?
        3. Challenges & Pain Points: What challenges might this company be facing based on their description and industry?
        4. Growth Opportunities: Where could they expand or improve?
        5. Value Proposition: How could {company_name}'s {hero_offer} help them address their challenges?
        
        Make the report factual, balanced, and insightful. Focus on how {hero_offer} ({hero_offer_details}) 
        could specifically help them overcome challenges or capture opportunities.
        
        Format in markdown with clear headings for each section.
        """
        
        try:
            # Call Anthropic Claude API
            response = client.messages.create(
                model="claude-3-opus-20240229",  # You can use other Claude models like "claude-3-sonnet-20240229" or "claude-3-haiku-20240307"
                max_tokens=1500,
                temperature=0.7,  # Slightly creative but mostly factual
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_prompt}
                ]
            )
            
            # Extract and save the research
            market_research = response.content[0].text
            research_df.at[idx, 'market_research'] = market_research
            
            print(f"✓ Successfully generated market research for {company_name_from_row}")
            print(f"  - Research length: {len(market_research)} chars")
            
            # Add a small delay to avoid rate limits
            time.sleep(1)
            
        except Exception as e:
            error_message = str(e)
            print(f"✗ Error generating market research for {company_name_from_row}: {error_message}")
            research_df.at[idx, 'market_research'] = f"Error: {error_message}"
            
            # If we encounter an API error, sleep a bit longer to respect rate limits
            if "rate limit" in error_message.lower():
                print("Rate limit encountered, sleeping for 30 seconds...")
                time.sleep(30)
            else:
                time.sleep(2)
    
    # For demonstration purposes, if no API key, add mock data
    if not api_key:
        print("\nNote: Using mock market research data since no Anthropic API key was provided.")
        for idx, row in research_df.iterrows():
            if pd.isna(research_df.at[idx, 'market_research']):
                research_df.at[idx, 'market_research'] = f"""
                # Market Research: {row['company_name']}
                
                ## Company Overview
                Based on the available information, {row['company_name']} appears to be in the software industry.
                
                ## Industry Analysis
                The software industry is growing rapidly with increased demand for automation and data solutions.
                
                ## Challenges & Pain Points
                Common challenges include technical debt, scaling, and talent acquisition.
                
                ## Growth Opportunities
                Potential to expand into new markets and develop integrated solutions.
                
                ## Value Proposition
                Our Data Pipeline Solution could help streamline their data operations.
                """
    
    print(f"\nGenerated market research for {len(research_df)} companies")
    return research_df