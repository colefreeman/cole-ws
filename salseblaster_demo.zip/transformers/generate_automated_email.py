if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
import time
import anthropic

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
import time
import anthropic

@transformer
def generate_personalized_emails(df, *args, **kwargs):
    """
    Generate complete 3-line personalized emails based on market research
    and return only the email text.
    
    Args:
        df (DataFrame): Contact data with market research
    
    Returns:
        DataFrame: Just the personalized email text
    """
    # Make a copy of the input dataframe but we'll only return the email
    result_emails = []
    
    # Anthropic API key - you'll insert your actual key here
    api_key = "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"
    
    # Initialize Anthropic client
    client = anthropic.Anthropic(api_key=api_key)
    
    # Get company info and email configuration from pipeline parameters or set defaults
    company_name = kwargs.get('company_name', 'Our Company')
    hero_offer = kwargs.get('hero_offer', 'Our Data Pipeline Solution')
    sender_name = kwargs.get('sender_name', 'Alex')
    sender_title = kwargs.get('sender_title', 'Growth Manager')
    
    # Process each row
    for idx, row in df.iterrows():
        # Skip if missing market research
        if pd.isna(row.get('market_research')):
            print(f"Skipping {row.get('first_name', 'contact')} at {row.get('company_name', 'company')} - missing market research")
            result_emails.append("No email generated - missing market research")
            continue
            
        print(f"\nGenerating personalized email for: {row.get('first_name', 'contact')} at {row.get('company_name', 'company')}")
        
        # Extract relevant data
        first_name = row.get('first_name', 'there') if not pd.isna(row.get('first_name')) else "there"
        company = row.get('company_name', 'your company') if not pd.isna(row.get('company_name')) else "your company"
        market_research = row.get('market_research', '')
        job_title = row.get('job_title', 'professional') if not pd.isna(row.get('job_title')) else "professional"
        
        # Truncate market research if too long to fit in prompt
        if len(market_research) > 4000:
            market_research = market_research[:4000] + "..."
        
        # Prepare prompt for Claude
        system_prompt = """You are an expert at writing personalized, engaging sales emails.
        Your task is to create a brief but powerful 3-line email that feels personal, specific, 
        and conversational - not generic or salesy. Use the provided market research to craft a highly 
        relevant message that shows genuine understanding of the recipient's business and challenges."""
        
        user_prompt = f"""
        Write a personalized 3-line email to {first_name} at {company}, who works as a {job_title}.
        
        Use the following market research about their company to make it highly specific and relevant:
        
        {market_research}
        
        Guidelines for the personalized email:
        1. EXACTLY 3 lines total (with line breaks between them)
        2. First line should be a personalized opener that references specific information from the market research
        3. Second line should briefly introduce our {hero_offer} in a way that directly addresses their specific challenges
        4. Third line should be a soft call to action (like asking for a short call)
        5. Make it conversational and natural, not sales-y or pushy
        6. Show genuine understanding of their business situation
        
        DO NOT use phrases like "I noticed" or "I saw" too generically. Be specific about what you noticed.
        DO NOT say "I came across your company" or similar generic openings.
        DO focus on a specific insight, challenge, or opportunity mentioned in the research.
        DO make the email sound like it was written by a real person, not an AI.
        
        Just return the 3-line email, nothing else. No explanations.
        """
        
        try:
            # Call Anthropic Claude API - using the same model as previous block
            response = client.messages.create(
                model="claude-3-opus-20240229",  # Using Opus model which was successful in previous block
                max_tokens=350,
                temperature=0.8,  # Slightly more creative for email writing
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_prompt}
                ]
            )
            
            # Extract and save the personalized email
            personalized_email = response.content[0].text
            
            # Clean up the email (remove extra whitespace)
            personalized_email = personalized_email.strip()
            
            # Ensure it's formatted properly with the sender's name at the end
            if not personalized_email.endswith(sender_name):
                personalized_email += f"\n\n{sender_name}\n{sender_title} | {company_name}"
                
            result_emails.append(personalized_email)
            
            print(f"✓ Successfully generated personalized email")
            print(f"  - Email preview: {personalized_email[:100]}...")
            
            # Add a small delay to avoid rate limits
            time.sleep(1)
            
        except Exception as e:
            error_message = str(e)
            print(f"✗ Error generating personalized email for {company}: {error_message}")
            result_emails.append(f"Error generating email: {error_message}")
            
            # If we encounter an API error, sleep a bit longer to respect rate limits
            if "rate limit" in error_message.lower():
                print("Rate limit encountered, sleeping for 20 seconds...")
                time.sleep(20)
            else:
                time.sleep(2)
    
    # Create a new dataframe with just the emails
    email_df = pd.DataFrame({'personalized_email': result_emails})
    
    print(f"\nGenerated personalized emails for {len(df)} contacts")
    return email_df